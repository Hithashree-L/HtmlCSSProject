// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'
// import Head from './components/Head'
// import Name from './components/Name'
// import Img from './components/Img'
//import Datetime from './components/Datetime'
// import Miniprodate from './components/Miniprodate'
// import './components/Time.css'
import Movieh from "./components/Movieh"
import Movie from "./components/Movie" 
import Mdata from "./components/Mdata"
import './components/Movies.css'
let card=(val)=>{
  return(
    <Movie imgs={val.imgs}
    tittle={val.tittle}
    watch={val.watch}
    Aname={val.Aname}/>
  )
}

function App() {
  // const [count, setCount] = useState(0)

  return (
    
    <>
     {/* <Head/>
     <Name/>
     <Img/>
    <Datetime/> */}    {/*by uncommenting these lines one can access a project of date and time */}
    {/* <Miniprodate/> */}
    {/* <img src="https://picsum.photos/200/300" alt="error"></img> */}
    <Movieh/>
    {/* <Movie imgs={Mdata[0].imgs}
      tittle={Mdata[0].tittle}
      watch={Mdata[0].watch} 
      Aname={Mdata[0].Aname}        // this represents array of the movie project 
      /> */}
      {/* {Mdata.map(val,index,arrayName)} */}
      {Mdata.map(card)}       {/*instead of array map can be used*/}
    </>

  )
}

export default App
