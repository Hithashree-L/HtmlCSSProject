import React from 'react'
const time=new Date().getHours()
// const time=new Date(2024,10,5,18)
let greet=""
let css={
   color:"",
  fontStyle:"italic",
   backgroundColor:"white"
}
if((time>1 & time<12)){
    greet="Good Morning"
    css.color="green"
}
else if((time>=12 & time<19)){
    greet="Good Afternoon"
    css.color="orange"
}
else{
    greet="Good Night"
    css.color="blue"
}

const Time=()=>{
    return(
        <div className='card'>
         <h1 >Hello sir: <span style={css}>{greet}</span></h1>
         {/* style={{color:'blue'}} */}
        </div>
    )
}

export default Time