import React from 'react';

// const date=new Date().toLocaleDateString()
// const time=new Date().toLocaleTimeString()
const Para=()=>{
    return(
        <>
        <p>PES College</p>
        {/* <h1>Todays Date is {date}</h1>
        <h1>Time is {time}</h1> */}
        </>
    )
}
export default Para