import React from "react";

const List=()=>{
    return(
        <>
        <h>List</h>
    <ul>
      <li>Java</li>
      <li>CSS</li>
      <li>HTML</li>
      <li>JavaScript</li>
    </ul>
        </>
    )
}
export default List