import React from 'react';
import Para from './Para';
import List from './List';
const Head=()=>{
    return(
        <>
        <h1 contentEditable="false">Welcome</h1>
        <h1 contentEditable="true">Editable</h1>
        <Para/>
        <List/>
        </>
    )
}
export default Head