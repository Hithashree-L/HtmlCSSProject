import React from 'react';

const name="Hitha"
const lname="shree"
const Name=()=>{
    return(
        <>
        <h>{name}{lname}</h><br></br>
        </>
    )
}
export default Name