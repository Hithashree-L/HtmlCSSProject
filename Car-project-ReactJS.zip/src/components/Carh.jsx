import React from 'react'

const Carh=()=>{
    return(
        <div>
        <div>
            <h1 className="head">Top 5 best movies</h1>
        </div>
        </div>
    )
}
export default Carh