import React from 'react'

const Car = (props) => {
    return (
            
            <div className="Main">
                <div className="Maincard">
                    <div className="Card">
                        <div className="imgs">
                            <img className="img" src={props.imgs} alt="error"></img>
                        </div>
                        <div className="Cdata">
                            <h4>{props.Cprice}</h4>
                            <a href={props.Description}>
                                <button className="btn">Features</button>
                            </a>
                            <div className="CarName">
                                <h4>{props.Cname}</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
        
        
    )
}
export default Car