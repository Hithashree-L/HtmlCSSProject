let Cdata=[
    {
        imgs:"https://cdni.autocarindia.com/ExtraImages/20210716051219_Mahindra_Bolero_Neo_lead.jpg",
        Cprice:"RS.10.91Lakh",
        Description:"https://www.bing.com/ck/a?!&&p=f1f2f8b3a2ee6686JmltdHM9MTcxODMyMzIwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTIyOQ&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=mahidra+bolero+description&u=a1aHR0cHM6Ly9hdXRvLm1haGluZHJhLmNvbS9zdXYvYm9sZXJv&ntb=1",
        Cname:"Bolero"
    },
    {
        imgs:"https://media.autoexpress.co.uk/image/private/s--h0m4VoBV--/v1609842715/autoexpress/2021/01/Used%20Hyundai%20Ioniq-6.jpg",
        Cprice:"Rs.6,32,500",
        Description:"https://www.bing.com/ck/a?!&&p=0204879996488ba1JmltdHM9MTcxODMyMzIwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI1MA&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=Hyundai&u=a1aHR0cHM6Ly93d3cuaHl1bmRhaS5jb20vaW4vZW4&ntb=1",
        Cname:"Hyundai"
    },
    {
        imgs:"https://th.bing.com/th/id/R.f697fa76b54e0457758bc5e7fd67d837?rik=XMYydIjLTtNTNQ&riu=http%3a%2f%2fi.ndtvimg.com%2fauto%2fmakers%2f29%2f200%2fmaruti-suzuki.jpg&ehk=idDwCp%2fhHszq0z0EF6cQGDbqjOwxgStL0LHLBUN0psQ%3d&risl=&pid=ImgRaw&r=0",
        Cprice:"Rs.3.99Lakh",
        Description:"https://www.bing.com/ck/a?!&&p=6f311a7d93116ca8JmltdHM9MTcxODMyMzIwMCZpZ3VpZD0yMGRlNDM3Yi1jMTE0LTY1NDgtM2FlOS01MTQzYzBiOTY0YzAmaW5zaWQ9NTI0NA&ptn=3&ver=2&hsh=3&fclid=20de437b-c114-6548-3ae9-5143c0b964c0&psq=Maruti&u=a1aHR0cHM6Ly93d3cubWFydXRpc3V6dWtpLmNvbS8&ntb=1",
        Cname:"Maruti"
    },
]

export default Cdata