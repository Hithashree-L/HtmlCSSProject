import React from "react";
import { useMemo,useState } from "react";

const Usememo=()=>{
    let[Add,setAdd]=useState(0)
    let[Sub,setSub]=useState(100)

    let mul=useMemo(()=>{
        return Add*10,console.log("click")
    },[Add])
    return(
        <div>
            <h1>add : {Add} mul {mul}</h1>
            <button onClick={()=>{setAdd(Add+1)}}>add</button><br></br>
            <h1>Sub:{Sub}</h1>
            <button onClick={()=>{setSub(Sub-1)}}>sub</button><br></br>
        </div>
    )
}

export default Usememo