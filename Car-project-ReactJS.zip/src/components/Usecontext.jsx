import React from 'react'
import { useContext } from 'react'
import { data,data1 } from '../App'

let Usecontext=()=>{
    let name=useContext(data)
    let age=useContext(data1)
    return(
        <>
        <h1>Name is : {name}  age is : {age}</h1>
        </>
    )
}
export default Usecontext