import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
const Incdec=()=>{
    let[Count,setCount]=useState(0)
    let inc=()=>{
        setCount(Count+1)
    
}
let dec=()=>{
    setCount(Count-1)
}
useEffect(()=>{
    alert("allow")
})
    return(
       
        <div>
             <>
            <h1>Count : {Count} </h1>
            <button onClick={inc}>INC</button>&nbsp;
            <button onClick={dec}>DEC</button>
            </>
        </div>
        
    )
}

export default Incdec