// import logo from './logo.svg';
// import './App.css';
import Carh from "./components/Carh";
import Car from "./components/Car";
import Cdata from "./components/Cdata";
import './components/Cars.css'
// import { createContext } from "react";
// import Usecontext from "./components/Usecontext"
// import Incdec from "./components/Incanddec";
// import Usememo from "./components/Usememo";

let card=(val)=>{
  return(
    <Car imgs={val.imgs}
    Cprice={val.Cprice}
    Description={val.Description}
    Cname={val.Cname}/>
  )
}
// let data=createContext("name")
// let data1=createContext("age")

function App() {
  // let name="Hitha"
  // let age=20
  return (
    // <>
    // <data.Provider value={name}>
    //   <data1.Provider value={age}>
    //     <Usecontext/>
    //   </data1.Provider>
    // </data.Provider>
    // </>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
    <>
    <Carh/>
    <div className="itms">
    {Cdata.map(card)} 
    </div> 
    {/* <Incdec/> */}
    {/* <Usememo/> */}
    </>
  )
}

export default App;
// export {data,data1}