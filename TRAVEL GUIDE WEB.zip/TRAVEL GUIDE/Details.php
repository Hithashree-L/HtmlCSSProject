<?php
$first=$_POST["First"];
$last=$_POST["Last"];
$email=$_POST["Email"];
$phone=input(INPUT_POST,"Phone",FILTER_VALIDATE_INT);
$address=$_POST["Address"];
$address2=$_POST["Address2"];
$city=$_POST["city"];
$region=$_POST["Region"];
$zip=filter_input(INPUT_POST,"Zip",FILTER_VALIDATE_INT);
$place=$_POST["place"];
$address3=$_POST["Address3"];
$address4=$_POST["Address4"];
// $host="localhost";
// $dbname="travellers_details";
// $username="root";
// $password="";
//  $conn=mysqli_connect($host,$username,$password,$dbname);it represents an object that represents the connection to the database
// if(mysqli_connect_errno()){
// die("Connection error:".mysqli_connect_errno());
//  }
//  echo "Connection Successful.";
// $sql="INSERT INTO Details(Firstname,Lastname,Email,Phone,Pick_street_address,Pick_street_address2,City,Region,Zipcode,Pick_District,Drop_street_address,Drop_street_address2) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
// $stmt=mysqli_stmt_init($conn);
// if(!mysqli_stmt_prepare($stmt,$sql)){
//   die(mysqli_connect_errno($conn));
// }
// mysqli_stmt_bind_param($stmt,"sssissssisss",$first,$last,$email,$phone,$address,$address2,$city,$region,$zip,$place,$address3,$address4);
// mysqli_stmt_execute($stmt);
// echo "Details given are saved.";
if(!empty($first)||!empty($last)||!empty($email)||!empty($phone)||!empty($address)||!empty($address2)||!empty($city)||!empty($region)||!empty($zip)||!empty($place)||!empty($address3)||!empty($address4))
{
  $host="localhost";
  $dbname="travellers_details";
  $username="root";
  $password="";
  
  $conn=new mysqli($host,$username,$password,$daname);
  if(mysqli_connect_errno()){
    die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
  }
  else{
    $SELECT="SELECT email from details WHERE email=? Limit=1";
    $INSERT= "INSERT Into details(Firstname,Lastname,Email,Phone,
    Pick_street_saddress,Pick_street_address2,City,Region,Zipcode,Pick_District,Drop_street_address,Drop_street_address2) values(?,?,?,?,?,?,?,?,?,?,?,?)";
    // prepare statement
     $stmt=$conn->prepare($SELECT);
   
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->store_result();
    $rnum=$stmt->num_rows;
    if($rnum==0)
    {
      $stmt->close();
      $stmt=$conn->prepare($INSERT);
      $stmt->bind_param("sssissssisss", $first,$last,$email,$phone,$address,$address2,$city,$region,$zip,$place,$address3,$address4);
      $stmt->execute();
      echo "New record inserted successfully";
    }
    else{
      echo "Someone already register using this email";
    }
    $stmt->close();
    $conn->close();
   
  }
}


else {
echo "All fields are requirde";
die();
}
?>