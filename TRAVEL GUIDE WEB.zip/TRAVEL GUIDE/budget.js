var bug=document.getElementById("budget");


function budget(bug){
  if(bug<=5000)
  {
alert("Hi");
  }

}