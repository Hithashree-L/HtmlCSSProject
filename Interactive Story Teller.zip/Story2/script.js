let currentStory = null;
let currentSceneIndex = 0;

const storyData = {
  "fantasy": [
    {
      title: "The Dragon's Trial",
      scenes: [
        {
          text: "You arrive at the cave of the ancient dragon. It guards a treasure known to grant immortality.",
          choices: [
            { text: "Challenge the dragon", next: 1 },
            { text: "Look for another way in", next: 2 }
          ]
        },
        {
          text: "The dragon roars and breathes fire. You raise your shield and charge!",
          choices: [
            { text: "Aim for the heart", next: 3 },
            { text: "Try to talk to it", next: 4 }
          ]
        },
        {
          text: "You sneak into a narrow tunnel and find a back entrance.",
          choices: [
            { text: "Enter quietly", next: 4 },
            { text: "Set a trap", next: 3 }
          ]
        },
        { text: "You strike true and defeat the dragon. The treasure is yours. 🏆", choices: [] },
        { text: "The dragon listens and offers wisdom. You gain knowledge beyond riches. 🧠", choices: [] }
      ]
    }
  ],
  "sci-fi": [
    {
      title: "Echoes of Mars",
      scenes: [
        {
          text: "You land on Mars to investigate strange signals from an abandoned base.",
          choices: [
            { text: "Explore the base", next: 1 },
            { text: "Scan the area first", next: 2 }
          ]
        },
        {
          text: "Inside, you find logs about an experiment gone wrong.",
          choices: [
            { text: "Access the mainframe", next: 3 },
            { text: "Look for survivors", next: 4 }
          ]
        },
        {
          text: "You detect movement underground.",
          choices: [
            { text: "Dig deeper", next: 3 },
            { text: "Leave quickly", next: 4 }
          ]
        },
        { text: "You unlock secrets of time travel. 🚀", choices: [] },
        { text: "A Martian entity contacts you — your mind expands. 🧠", choices: [] }
      ]
    }
  ],
  "horror": [
    {
      title: "The Haunted House",
      scenes: [
        {
          text: "You enter the abandoned house at the end of the street. A chill runs down your spine.",
          choices: [
            { text: "Explore the basement", next: 1 },
            { text: "Go upstairs", next: 2 }
          ]
        },
        {
          text: "The basement is dark, and you hear strange noises from the shadows.",
          choices: [
            { text: "Investigate the noise", next: 3 },
            { text: "Run back upstairs", next: 4 }
          ]
        },
        {
          text: "You find a ghostly figure at the top of the stairs. It whispers your name.",
          choices: [
            { text: "Confront the ghost", next: 3 },
            { text: "Escape through the window", next: 4 }
          ]
        },
        { text: "You confront the ghost and uncover its tragic past. 🕊️", choices: [] },
        { text: "You escape the house, but the ghost follows you forever. 👻", choices: [] }
      ]
    }
  ],
  // Add more genres here...
};

function showStoryList(genre) {
  document.getElementById("genre-selection").classList.add("hidden"); // Hide genre selection
  const listSection = document.getElementById("story-list");
  const container = document.getElementById("stories-container");
  const title = document.getElementById("genre-title");

  title.textContent = `Choose a story from ${genre.toUpperCase()}`;
  container.innerHTML = "";

  storyData[genre].forEach((story, idx) => {
    const btn = document.createElement("button");
    btn.textContent = story.title;
    btn.onclick = () => startStory(genre, idx);
    container.appendChild(btn);
  });

  listSection.classList.remove("hidden"); // Show story list
}

function startStory(genre, index) {
  currentStory = storyData[genre][index];
  currentSceneIndex = 0;
  document.getElementById("story-list").classList.add("hidden");
  document.getElementById("story-container").classList.remove("hidden");
  showScene();
}

function showScene() {
  const scene = currentStory.scenes[currentSceneIndex];
  document.getElementById("story-content").textContent = scene.text;

  const choicesDiv = document.getElementById("choices");
  choicesDiv.innerHTML = "";

  scene.choices.forEach(choice => {
    const btn = document.createElement("button");
    btn.textContent = choice.text;
    btn.onclick = () => {
      currentSceneIndex = choice.next;
      showScene();
    };
    choicesDiv.appendChild(btn);
  });
}

function goBack() {
  document.getElementById("story-list").classList.add("hidden");
  document.getElementById("genre-selection").classList.remove("hidden");
}

function goHome() {
  document.getElementById("story-container").classList.add("hidden");
  document.getElementById("genre-selection").classList.remove("hidden");
}
