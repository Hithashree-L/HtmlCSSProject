let currentStory = null;
let currentSceneIndex = 0;

const storyData = {
  "fantasy": [
    {
      title: "The Dragon's Trial",
      scenes: [
        {
          text: "You arrive at the cave of the ancient dragon. It guards a treasure known to grant immortality.",
          choices: [
            { text: "Challenge the dragon", next: 1 },
            { text: "Look for another way in", next: 2 }
          ]
        },
        {
          text: "The dragon roars and breathes fire. You raise your shield and charge!",
          choices: [
            { text: "Aim for the heart", next: 3 },
            { text: "Try to talk to it", next: 4 }
          ]
        },
        {
          text: "You sneak into a narrow tunnel and find a back entrance.",
          choices: [
            { text: "Enter quietly", next: 4 },
            { text: "Set a trap", next: 3 }
          ]
        },
        { text: "You strike true and defeat the dragon. The treasure is yours. 🏆", choices: [] },
        { text: "The dragon listens and offers wisdom. You gain knowledge beyond riches. 🧠", choices: [] }
      ]
    }
  ],
  "sci-fi": [
    {
      title: "Echoes of Mars",
      scenes: [
        {
          text: "You land on Mars to investigate strange signals from an abandoned base.",
          choices: [
            { text: "Explore the base", next: 1 },
            { text: "Scan the area first", next: 2 }
          ]
        },
        {
          text: "Inside, you find logs about an experiment gone wrong.",
          choices: [
            { text: "Access the mainframe", next: 3 },
            { text: "Look for survivors", next: 4 }
          ]
        },
        {
          text: "You detect movement underground.",
          choices: [
            { text: "Dig deeper", next: 3 },
            { text: "Leave quickly", next: 4 }
          ]
        },
        { text: "You unlock secrets of time travel. 🚀", choices: [] },
        { text: "A Martian entity contacts you — your mind expands. 🧠", choices: [] }
      ]
    }
  ],
  "horror": [
    {
      title: "The Haunted House",
      scenes: [
        {
          text: "You enter the abandoned house at the end of the street. A chill runs down your spine.",
          choices: [
            { text: "Explore the basement", next: 1 },
            { text: "Go upstairs", next: 2 }
          ]
        },
        {
          text: "The basement is dark, and you hear strange noises from the shadows.",
          choices: [
            { text: "Investigate the noise", next: 3 },
            { text: "Run back upstairs", next: 4 }
          ]
        },
        {
          text: "You find a ghostly figure at the top of the stairs. It whispers your name.",
          choices: [
            { text: "Confront the ghost", next: 3 },
            { text: "Escape through the window", next: 4 }
          ]
        },
        { text: "You confront the ghost and uncover its tragic past. 🕊️", choices: [] },
        { text: "You escape the house, but the ghost follows you forever. 👻", choices: [] }
      ]
    }
  ],
  "mystery": [
    {
      title: "The Vanishing",
      scenes: [
        {
          text: "A person has gone missing in the city. You investigate the last place they were seen.",
          choices: [
            { text: "Talk to the witnesses", next: 1 },
            { text: "Search the nearby park", next: 2 }
          ]
        },
        {
          text: "The witnesses tell you about a strange figure they saw near the scene.",
          choices: [
            { text: "Follow the witness's lead", next: 3 },
            { text: "Investigate the park", next: 4 }
          ]
        },
        {
          text: "The park is eerily quiet. You notice something strange under the trees.",
          choices: [
            { text: "Investigate further", next: 5 },
            { text: "Call for backup", next: 6 }
          ]
        },
        { text: "You find the missing person, locked in a hidden basement. 🏚️", choices: [] },
        { text: "You discover a secret society operating in the city. 🕵️‍♀️", choices: [] }
      ]
    }
  ],
  "adventure": [
    {
      title: "Lost in the Jungle",
      scenes: [
        {
          text: "You’re stranded in the jungle after your plane crashes. The forest seems alive with sounds.",
          choices: [
            { text: "Explore the area", next: 1 },
            { text: "Stay put and wait for rescue", next: 2 }
          ]
        },
        {
          text: "You discover a hidden path leading deeper into the jungle.",
          choices: [
            { text: "Follow the path", next: 3 },
            { text: "Climb a tree to get a better view", next: 4 }
          ]
        },
        {
          text: "A massive creature emerges from the undergrowth. It’s too late to escape.",
          choices: [
            { text: "Fight the creature", next: 5 },
            { text: "Try to hide", next: 6 }
          ]
        },
        { text: "You defeat the creature and find a way out of the jungle. 🏆", choices: [] },
        { text: "You find an ancient temple hidden deep within the jungle. 🏯", choices: [] }
      ]
    }
  ],
  "historical-fiction": [
    {
      title: "The Pharaoh's Curse",
      scenes: [
        {
          text: "You are a tomb raider in ancient Egypt, entering the pyramid of a forgotten pharaoh.",
          choices: [
            { text: "Explore the burial chamber", next: 1 },
            { text: "Search the outer rooms", next: 2 }
          ]
        },
        {
          text: "You open the burial chamber and see a golden sarcophagus with strange symbols.",
          choices: [
            { text: "Open the sarcophagus", next: 3 },
            { text: "Leave the room", next: 4 }
          ]
        },
        {
          text: "A curse is unleashed as you open the sarcophagus. The walls start to close in!",
          choices: [
            { text: "Fight the curse", next: 5 },
            { text: "Escape the tomb", next: 6 }
          ]
        },
        { text: "You break the curse and escape the pyramid. 🏆", choices: [] },
        { text: "You unleash an ancient evil and must fight for survival. ⚔️", choices: [] }
      ]
    }
  ],
  "romance": [
    {
      title: "Summer Romance",
      scenes: [
        {
          text: "You meet someone new at a summer party by the beach. Sparks fly instantly.",
          choices: [
            { text: "Ask them out for coffee", next: 1 },
            { text: "Wait for them to make the first move", next: 2 }
          ]
        },
        {
          text: "You enjoy a quiet coffee date, and things seem to be going well.",
          choices: [
            { text: "Go for a walk together", next: 3 },
            { text: "Ask about their past", next: 4 }
          ]
        },
        {
          text: "The walk is magical. You feel a deeper connection forming.",
          choices: [
            { text: "Kiss them", next: 5 },
            { text: "Confess your feelings", next: 6 }
          ]
        },
        { text: "You fall in love and spend the rest of the summer together. ❤️", choices: [] },
        { text: "You realize you’re not ready for love but remain friends. 🌞", choices: [] }
      ]
    }
  ]
};
